import type { IconName } from './iconData';
export type { IconName, LucideIconName } from './iconData';
import type { ReactNode, SVGProps } from 'react';
export type IconOverrides = Partial<Record<IconName, ReactNode>>;
/** Overrides use the shared 24 × 24 SVG coordinate system and inherit currentColor. */
export declare function IconProvider({ icons, children }: {
    icons: IconOverrides;
    children: ReactNode;
}): import("react").JSX.Element;
export type IconProps = SVGProps<SVGSVGElement> & {
    name: IconName;
};
export declare function Icon({ name, className, ...props }: IconProps): import("react").JSX.Element;
