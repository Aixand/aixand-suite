# Changelog

## Unreleased

- Add outlined, subtle, and plain field variants alongside the default filled
  treatment across text, dropdown, number, date/time, password/code, and tag fields.
  Add compact SearchField with clearing, Escape, native form reset, and translated
  labels. Use compact search/filter controls in Gallery and product compositions;
  keep command search and inline editing compact. Add Field styles and Search field
  examples and style choices in individual previews and the Profile form.

- Toast notifications support optional actions such as Undo, with an accessible
  label and consumer-controlled dismissal after the operation succeeds.

- Brand workspace follows Gallery’s mode until a preview mode is chosen; media demo artwork updates its canvas and palette when the theme changes.

- ThemeSwitcher uses a single sun/moon icon button for direct light/dark changes
  on click or keyboard activation. Remove its `variant` prop and three-option
  segmented presentation; Gallery uses the same icon button as the top navigation.
  System remains available in AppearanceSettings.

- Add sixteen shared product utility components, including the sun/moon icon
  ThemeSwitcher, appearance settings, account/workspace controls, notification
  center, code/copy tools, status/banner/bulk controls, tree, split pane, context
  menu, and image preview. Add English/Arabic labels and public APIs.
- Extend command items with navigation links and shortcut hints; allow controlled
  DropdownMenu state for contextual actions.
- Gallery now starts in System mode, exposes a dedicated theme control, persists
  navigation/search in URLs, and provides isolated examples, resets, lazy-loaded
  source, and API links. Add seventeen component examples using the shared controls.
- Expand Settings with profile, appearance, language, and account actions; compose
  shared account/workspace controls and consistent product appearance/notifications.


- Reusable BrandPreset objects, createBrand, and BrandLogo; retain named BBB/Studio
  presets and support consumer identities without component changes.
- Brand workspace with identity/token editing, light/dark previews, 38-pair contrast
  checks, local persistence, validated JSON import, and JSON/scoped CSS export.
- Independent heading/wordmark font roles and supporting pressed colors. Explicit
  nested brands reset inherited token overrides; mode changes resolve their own
  palette. Reduced-motion preferences override custom transition durations.

- Define the BBB wordmark as lowercase `bbb.` with an accent-colored final period,
  for BBB product identity.

- Sliders lift with animated hover/drag shadows and settle on release. Add optional
  `keyboardStep`; Gallery sliders drag smoothly while arrow keys adjust by five.

- Keep Select dropdown chevrons vertically centered while opening and closing.

- Clearer sidebar hierarchy with indented child links, stronger
  parent labels, and child selection fills inset beneath their parent.

- Sidebar page dropdowns with nested destinations; the Gallery pattern defaults
  to static section labels and retains a Sections variant.

- Content and Internationalization foundations, with English/Arabic shared-control
  dictionaries, typed message overrides, localized numbers, and RTL portal support.
- PasswordField, VerificationCode, DescriptionList, Toolbar, InlineEdit,
  CommandSearch, and CommandPalette. Authentication reuses the new fields.
- Optional table column visibility, pointer/keyboard resizing, and expandable rows;
  Advanced table and Workspace search patterns demonstrate complete interactions.
- Cross-browser completion checks in Chromium, Firefox, and WebKit; a pinned
  container runner and reviewed Gallery screenshot baselines; catalog-aware counts.
- Keep calendars and date-picker popups sized to their seven day columns, with
  internal scrolling at narrow widths and enlarged text.
- Correct slider fill thickness, enlarge handles, and retain comfortable drag
  targets. Add `--bbb-slider-track-height` for independent track customization.

## 0.2.0 — 2026-10-14

- Standardize interface icons on Lucide through the shared Icon component and
  runtime dependency. Add canonical names for navigation, terminal, workflow,
  voice, and editing controls; keep the original BBB names as compatible aliases.
- Preserve decorative SVG semantics, directional mirroring, token customization,
  and nested IconProvider artwork overrides across canonical names and aliases.
  Set the default icon stroke to 2.
- Show the canonical Lucide selection in Gallery's Iconography foundation and
  document the shared icon convention for consuming products.

## 0.1.1 — 2026-10-13

- Keep tooltip text readable in light and dark modes when theme styles load after
  component styles. Portaled tooltips retain their inverse text/surface colors
  across BBB, Studio, and consumer brands.

## 0.1.0 — 2026-09-22

- Expandable SidebarNavigation groups with keyboard disclosures, icon-rail
  support, and a Sidebar dropdowns Gallery pattern.

- First local-installable ES module library with exported component prop types,
  explicit styles/token entry points, and React peer dependencies.
- BBB and Studio themes with light/dark/system modes, density, scoped token
  overrides, portal inheritance, and Gallery appearance preferences/CSS export.
- Custom icon artwork, rich option/menu content, sidebar icon slots, and overlay
  classes, with documented customization conventions.
- Calendar, date/date-range/time pickers, number field, multi-select, tag entry,
  file upload, slider/range slider, segmented control, and stepper.
- Motion, iconography, layout/density, interaction states, customization, themes,
  and live contrast Gallery foundations.
- Authentication/recovery, onboarding, multi-step form, unsaved changes, and page
  recovery patterns, with local simulations and no backend integration.
- Existing components retain their current props and behavior. Root-only token
  overrides should move to ThemeProvider `tokens` when using scoped providers,
  especially for portaled content. See docs/CUSTOMIZATION.md.

### Gallery navigation refresh

- Gallery and Workspace shell default to a branded identity area with the sidebar toggle. Workspace shell also demonstrates a document layout without a logo or global header.
- Gallery has direct product destinations and bottom Help & resources with downloadable guides.
- Workspace shell demonstrates a combined account/workspace popover, workspace switching, editable account name, and local logout/sign-in.
- `--bbb-shell-header-height` coordinates the Gallery header and fixed navigation offset.

- Replace the bbb-notes card layout with a logo-free library sidebar and document
  workspace, including notebook filters, a collapsed navigation rail, mobile library
  sheet, and account/workspace switching with separate local collections.

- Add DocumentWorkspace with navigation, document tools, account, content, and footer
  slots. Workspace shell’s Document pattern and bbb-notes share its responsive
  layout, icon rail, mobile navigation, and focus restoration.
