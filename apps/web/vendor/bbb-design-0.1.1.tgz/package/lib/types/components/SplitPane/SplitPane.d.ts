import type { ReactNode } from 'react';
export type SplitPaneProps = {
    label: string;
    primary: ReactNode;
    children: ReactNode;
    className?: string;
    onResize?: (percent: number) => void;
};
export declare function SplitPane({ label, primary, children, className, onResize }: SplitPaneProps): import("react").JSX.Element;
