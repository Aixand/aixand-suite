import type { ButtonProps as AriaButtonProps } from 'react-aria-components';
import type { AriaAttributes, ReactNode, Ref } from 'react';
export type ButtonProps = Omit<AriaButtonProps, 'children' | 'className' | 'isDisabled' | 'render'> & AriaAttributes & {
    variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
    size?: 'sm' | 'md';
    loading?: boolean;
    disabled?: boolean;
    iconOnly?: boolean;
    className?: string;
    children?: ReactNode;
    ref?: Ref<HTMLButtonElement>;
};
export declare function Button({ variant, size, type, loading, disabled, iconOnly, children, className, ...props }: ButtonProps): import("react").JSX.Element;
