import type { CalendarProps as AriaCalendarProps, RangeCalendarProps as AriaRangeCalendarProps, DateValue } from 'react-aria-components';
export declare function CalendarContent(): import("react").JSX.Element;
export type CalendarProps<T extends DateValue> = Omit<AriaCalendarProps<T>, 'children' | 'className'> & {
    className?: string;
};
export declare function Calendar<T extends DateValue>({ className, ...props }: CalendarProps<T>): import("react").JSX.Element;
export type RangeCalendarProps<T extends DateValue> = Omit<AriaRangeCalendarProps<T>, 'children' | 'className'> & {
    className?: string;
};
export declare function RangeCalendar<T extends DateValue>({ className, ...props }: RangeCalendarProps<T>): import("react").JSX.Element;
