export type NotificationItem = {
    id: string;
    title: string;
    description?: string;
    time?: string;
    unread?: boolean;
};
export type NotificationCenterProps = {
    items: NotificationItem[];
    onRead: (id: string) => void;
    onReadAll?: () => void;
    onOpenItem?: (id: string) => void;
    loading?: boolean;
    error?: string;
    onRetry?: () => void;
    disabled?: boolean;
    className?: string;
};
export declare function NotificationCenter({ items, onRead, onReadAll, onOpenItem, loading, error, onRetry, disabled, className }: NotificationCenterProps): import("react").JSX.Element;
