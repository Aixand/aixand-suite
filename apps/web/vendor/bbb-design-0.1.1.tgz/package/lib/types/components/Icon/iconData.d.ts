import type { ReactNode } from 'react';
export type IconName = 'sun' | 'moon' | 'monitor' | 'copy' | 'bell' | 'settings' | 'folder' | 'image' | 'eye' | 'eye-off' | 'note' | 'calendar' | 'wallet' | 'app' | 'grid' | 'layers' | 'box' | 'search' | 'arrow' | 'check' | 'close' | 'sparkle' | 'space' | 'pointer' | 'chevron-down' | 'minus' | 'plus' | 'more' | 'trash' | 'info' | 'warning' | 'person' | 'chevron-right' | 'mail' | 'external' | 'chevron-left' | 'arrow-up' | 'arrow-down' | 'sort' | 'refresh' | 'menu' | 'sidebar';
export declare const paths: Record<IconName, ReactNode>;
export declare const iconNames: IconName[];
