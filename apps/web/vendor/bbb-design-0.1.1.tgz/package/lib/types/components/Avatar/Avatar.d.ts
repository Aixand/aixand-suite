export type AvatarProps = {
    name: string;
    src?: string;
    size?: 'sm' | 'md' | 'lg';
    tone?: 'neutral' | 'teal' | 'ember';
    decorative?: boolean;
    className?: string;
};
export declare function Avatar({ name, src, size, tone, decorative, className, }: AvatarProps): import("react").JSX.Element;
