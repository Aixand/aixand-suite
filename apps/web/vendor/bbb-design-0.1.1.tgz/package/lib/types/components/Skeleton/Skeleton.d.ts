export type SkeletonProps = {
    variant?: 'line' | 'title' | 'avatar';
    short?: boolean;
    className?: string;
};
export declare function Skeleton({ variant, short, className }: SkeletonProps): import("react").JSX.Element;
