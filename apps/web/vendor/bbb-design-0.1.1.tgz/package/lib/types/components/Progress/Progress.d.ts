export type ProgressProps = {
    label: string;
    value?: number;
    max?: number;
    className?: string;
};
export declare function Progress({ label, value, max, className }: ProgressProps): import("react").JSX.Element;
