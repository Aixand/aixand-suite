import type { ReactNode } from 'react';
import type { ThemeMode, Density } from '../ThemeProvider/ThemeProvider';
export type AppearanceSettingsProps = {
    mode: ThemeMode;
    onModeChange: (mode: ThemeMode) => void;
    density?: Density;
    onDensityChange?: (density: Density) => void;
    disabled?: boolean;
    children?: ReactNode;
    className?: string;
};
export declare function AppearanceSettings({ mode, onModeChange, density, onDensityChange, disabled, children, className }: AppearanceSettingsProps): import("react").JSX.Element;
