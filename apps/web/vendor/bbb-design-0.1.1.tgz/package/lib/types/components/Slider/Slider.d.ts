import type { SliderProps as AriaSliderProps } from 'react-aria-components';
export type SliderProps<T extends number | number[] = number> = Omit<AriaSliderProps<T>, 'children' | 'className' | 'isDisabled' | 'orientation'> & {
    label: string;
    hint?: string;
    disabled?: boolean;
    className?: string;
    thumbLabels?: string[];
    names?: string[];
    keyboardStep?: number;
};
export declare function Slider<T extends number | number[]>({ label, hint, disabled, className, thumbLabels, names, keyboardStep, ...props }: SliderProps<T>): import("react").JSX.Element;
export type RangeSliderProps = Omit<SliderProps<number[]>, 'thumbLabels'> & {
    thumbLabels?: [string, string];
};
export declare function RangeSlider({ defaultValue, ...props }: RangeSliderProps): import("react").JSX.Element;
