export type InlineEditProps = {
    label: string;
    value: string;
    onSave: (value: string) => void;
    validate?: (value: string) => string | undefined;
    disabled?: boolean;
    className?: string;
};
export declare function InlineEdit({ label, value, onSave, validate, disabled, className }: InlineEditProps): import("react").JSX.Element;
