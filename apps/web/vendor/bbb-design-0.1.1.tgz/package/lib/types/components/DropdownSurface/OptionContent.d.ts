import type { ReactNode } from 'react';
export type ChoiceOption = {
    id: string;
    label: string;
    description?: string;
    leading?: ReactNode;
    disabled?: boolean;
};
/** textValue stays separate from rich option content for typeahead and naming. */
export declare function OptionContent({ option }: {
    option: ChoiceOption;
}): import("react").JSX.Element;
