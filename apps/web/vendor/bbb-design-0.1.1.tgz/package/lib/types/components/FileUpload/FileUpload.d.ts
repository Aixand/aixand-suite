export type UploadFile = {
    id: string;
    file: File;
    status: 'ready' | 'uploading' | 'complete' | 'error';
    progress?: number;
    error?: string;
};
export type FileUploadProps = {
    label: string;
    files: UploadFile[];
    onAdd: (files: File[]) => void;
    onRemove: (id: string) => void;
    onRetry?: (id: string) => void;
    accept?: string;
    multiple?: boolean;
    maxSize?: number;
    disabled?: boolean;
    hint?: string;
    error?: string;
    className?: string;
};
export declare function FileUpload({ label, files, onAdd, onRemove, onRetry, accept, multiple, maxSize, disabled, hint, error, className, }: FileUploadProps): import("react").JSX.Element;
