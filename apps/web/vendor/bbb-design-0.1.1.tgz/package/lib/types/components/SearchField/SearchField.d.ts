import type { TextFieldProps } from '../TextField/TextField';
import type { FieldVariant } from '../FormField/FieldSurface';
export type SearchFieldProps = Omit<TextFieldProps, 'type' | 'hideLabel' | 'leadingIcon' | 'trailingAction' | 'value' | 'defaultValue' | 'onChange' | 'variant'> & {
    value?: string;
    defaultValue?: string;
    onChange?: (value: string) => void;
    variant?: Exclude<FieldVariant, 'filled'>;
    clearLabel?: string;
};
/** A compact search input; the consumer owns filtering, results, and submission. */
export declare function SearchField({ value, defaultValue, onChange, variant, clearLabel, ref, className, onKeyDown, ...props }: SearchFieldProps): import("react").JSX.Element;
