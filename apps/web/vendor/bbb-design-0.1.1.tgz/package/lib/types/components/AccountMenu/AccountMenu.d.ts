import type { ReactElement, ReactNode } from 'react';
export type AccountMenuAction = {
    id: string;
    label: string;
    disabled?: boolean;
    danger?: boolean;
};
export type AccountMenuProps = {
    name: string;
    email?: string;
    avatarSrc?: string;
    trigger?: ReactElement;
    actions?: AccountMenuAction[];
    onAction?: (id: string) => void;
    children?: ReactNode;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    className?: string;
};
/** A popover, rather than an ARIA menu, so settings and form controls can be composed inside. */
export declare function AccountMenu({ name, email, avatarSrc, trigger, actions, onAction, children, open, onOpenChange, className }: AccountMenuProps): import("react").JSX.Element;
