import type { ReactElement, ReactNode } from 'react';
export type MenuAction = {
    id: string;
    label: string;
    disabled?: boolean;
    danger?: boolean;
    leading?: ReactNode;
};
export type DropdownMenuProps = {
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    className?: string;
    renderItem?: (item: MenuAction) => ReactNode;
    trigger: ReactElement;
    label: string;
    items: MenuAction[];
    onAction: (id: string) => void;
};
export declare function DropdownMenu({ trigger, label, items, onAction, renderItem, open, onOpenChange, className }: DropdownMenuProps): import("react").JSX.Element;
