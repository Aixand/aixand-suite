import type { ReactNode } from 'react';
import type { Messages } from './messages';
export declare function LocaleMessages({ messages, children }: {
    messages?: Messages;
    children: ReactNode;
}): import("react").JSX.Element;
