import type { ComponentPropsWithRef, ReactNode } from 'react';
import type { FieldProps } from '../FormField/FormField';
export type TextFieldProps = ComponentPropsWithRef<'input'> & FieldProps & {
    leadingIcon?: ReactNode;
    trailingAction?: ReactNode;
};
export declare function TextField({ label, hideLabel, hint, error, variant, leadingIcon, trailingAction, id, className, 'aria-describedby': describedBy, ...props }: TextFieldProps): import("react").JSX.Element;
