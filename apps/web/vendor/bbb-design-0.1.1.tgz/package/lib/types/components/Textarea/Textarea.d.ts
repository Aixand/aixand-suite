import type { ComponentPropsWithRef } from 'react';
import type { FieldProps } from '../FormField/FormField';
export type TextareaProps = ComponentPropsWithRef<'textarea'> & FieldProps;
export declare function Textarea({ label, hideLabel, hint, error, variant, id, className, 'aria-describedby': describedBy, ...props }: TextareaProps): import("react").JSX.Element;
