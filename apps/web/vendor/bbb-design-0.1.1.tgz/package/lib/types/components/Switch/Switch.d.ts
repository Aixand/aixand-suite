import type { ComponentPropsWithRef } from 'react';
export type SwitchProps = Omit<ComponentPropsWithRef<'input'>, 'type' | 'role' | 'size'> & {
    label: string;
    description?: string;
};
export declare function Switch({ label, description, id, className, 'aria-describedby': describedBy, ...props }: SwitchProps): import("react").JSX.Element;
