import type { ChoiceOption } from '../DropdownSurface/OptionContent';
import type { ReactNode } from 'react';
import type { SelectProps as AriaSelectProps } from 'react-aria-components';
import type { Ref } from 'react';
import type { FieldProps } from '../FormField/FormField';
export type SelectOption = ChoiceOption;
export type SelectProps = Omit<AriaSelectProps<SelectOption>, 'children' | 'className' | 'value' | 'defaultValue' | 'onChange' | 'selectedKey' | 'defaultSelectedKey' | 'onSelectionChange' | 'isDisabled' | 'isRequired' | 'disabledKeys' | 'selectionMode'> & FieldProps & {
    options: SelectOption[];
    value?: string | null;
    defaultValue?: string;
    onChange?: (value: string) => void;
    disabled?: boolean;
    required?: boolean;
    renderOption?: (option: SelectOption) => ReactNode;
    className?: string;
    ref?: Ref<HTMLButtonElement>;
};
export declare function Select({ label, hideLabel, options, value, defaultValue, onChange, disabled, required, hint, error, variant, ref, renderOption, className, ...props }: SelectProps): import("react").JSX.Element;
