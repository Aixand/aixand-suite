import type { MessageKey, Messages } from './messages';
export declare const MessageContext: import("react").Context<{
    locale?: string;
    overrides: Messages;
}>;
export declare function useMessages(): {
    t: (key: MessageKey, values?: Record<string, string | number>) => string;
    locale: string;
    direction: import("@react-types/shared").Direction;
    formatNumber: (value: number) => string;
};
