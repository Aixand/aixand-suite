import type { Ref } from 'react';
import type { NumberFieldProps as AriaNumberFieldProps } from 'react-aria-components';
import type { FieldVariant } from '../FormField/FieldSurface';
export type NumberFieldProps = Omit<AriaNumberFieldProps, 'children' | 'className' | 'isDisabled' | 'isRequired'> & {
    ref?: Ref<HTMLInputElement>;
    label: string;
    hint?: string;
    error?: string;
    variant?: FieldVariant;
    disabled?: boolean;
    required?: boolean;
    className?: string;
};
export declare function NumberField({ label, hint, error, variant, disabled, required, ref, className, ...props }: NumberFieldProps): import("react").JSX.Element;
