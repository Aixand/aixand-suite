import type { Brand, ThemeMode, Density, ThemeTokens } from './theme';
export type { Brand, ThemeMode, Density, ThemeTokens } from './theme';
import type { HTMLAttributes } from 'react';
import type { Messages } from '../LocaleProvider/messages';
import type { BrandPreset } from '../../foundations/brands';
export type ThemeProviderProps = Omit<HTMLAttributes<HTMLDivElement>, 'dir'> & {
    brand?: Brand | BrandPreset;
    mode?: ThemeMode;
    density?: Density;
    tokens?: ThemeTokens;
    dir?: 'ltr' | 'rtl';
    locale?: string;
    messages?: Messages;
};
/** A theme boundary. Overlays copy the same boundary through React context. */
export declare function ThemeProvider({ brand, mode, density, tokens, dir, locale, messages, className, style, children, ...props }: ThemeProviderProps): import("react").JSX.Element;
