import type { HTMLAttributes, ReactNode } from 'react';
export type SettingsSectionProps = Omit<HTMLAttributes<HTMLElement>, 'title'> & {
    title: string;
    description?: string;
    headingLevel?: 2 | 3 | 4;
    children: ReactNode;
};
export declare function SettingsSection({ title, description, headingLevel, children, className, ...props }: SettingsSectionProps): import("react").JSX.Element;
