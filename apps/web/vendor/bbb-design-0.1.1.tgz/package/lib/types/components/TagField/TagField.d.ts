import type { FieldVariant } from '../FormField/FieldSurface';
export type TagFieldProps = {
    label: string;
    value?: string[];
    defaultValue?: string[];
    onChange?: (tags: string[]) => void;
    name?: string;
    hint?: string;
    error?: string;
    variant?: FieldVariant;
    disabled?: boolean;
    maxTags?: number;
    className?: string;
    placeholder?: string;
};
export declare function TagField({ label, value, defaultValue, onChange, name, hint, error, variant, disabled, maxTags, className, placeholder, }: TagFieldProps): import("react").JSX.Element;
