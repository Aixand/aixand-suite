import type { TextFieldProps } from '../TextField/TextField';
export type PasswordFieldProps = Omit<TextFieldProps, 'type' | 'trailingAction'> & {
    showLabel?: string;
    hideLabelText?: string;
};
export declare function PasswordField({ ref, id, showLabel, hideLabelText, ...props }: PasswordFieldProps): import("react").JSX.Element;
