import type { HTMLAttributes, ReactNode } from 'react';
import type { IconName } from '../Icon/Icon';
export type SidebarNavigationItem = {
    id: string;
    label: string;
    leading?: ReactNode;
    icon?: IconName;
    badge?: string;
    disabled?: boolean;
} & ({
    href: string;
    children?: never;
    defaultExpanded?: never;
} | {
    href?: never;
    children: SidebarNavigationItem[];
    defaultExpanded?: boolean;
});
export type SidebarNavigationGroup = {
    id: string;
    label?: string;
    items: SidebarNavigationItem[];
    collapsible?: boolean;
    defaultExpanded?: boolean;
    icon?: IconName;
};
export type SidebarNavigationProps = Omit<HTMLAttributes<HTMLElement>, 'onSelect'> & {
    label: string;
    groups: SidebarNavigationGroup[];
    currentId?: string;
    compact?: boolean;
    onNavigate?: (id: string) => void;
};
export declare function SidebarNavigation({ label, groups, currentId, compact, onNavigate, className, ...props }: SidebarNavigationProps): import("react").JSX.Element;
