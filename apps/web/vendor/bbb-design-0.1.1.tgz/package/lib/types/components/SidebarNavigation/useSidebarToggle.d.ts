export declare function useSidebarToggle(): {
    collapsed: boolean;
    buttonRef: import("react").RefObject<HTMLButtonElement | null>;
    toggle: () => void;
};
