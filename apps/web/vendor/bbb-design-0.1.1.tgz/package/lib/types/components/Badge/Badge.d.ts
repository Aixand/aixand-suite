import type { HTMLAttributes } from 'react';
export type BadgeProps = HTMLAttributes<HTMLSpanElement> & {
    tone?: 'neutral' | 'accent' | 'success' | 'warning';
    dot?: boolean;
};
export declare function Badge({ tone, dot, className, children, ...props }: BadgeProps): import("react").JSX.Element;
