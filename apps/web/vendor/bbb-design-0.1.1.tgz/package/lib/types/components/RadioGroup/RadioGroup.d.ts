import type { RadioGroupProps as AriaRadioGroupProps } from 'react-aria-components';
export type RadioGroupProps = Omit<AriaRadioGroupProps, 'children' | 'className' | 'isDisabled'> & {
    label: string;
    options: {
        value: string;
        label: string;
        description?: string;
        disabled?: boolean;
    }[];
    hint?: string;
    error?: string;
    disabled?: boolean;
    className?: string;
};
export declare function RadioGroup({ label, options, hint, error, disabled, className, ...props }: RadioGroupProps): import("react").JSX.Element;
