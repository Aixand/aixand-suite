import type { HTMLAttributes, ReactNode } from 'react';
import type { IconName } from '../Icon/Icon';
export type EmptyStateProps = Omit<HTMLAttributes<HTMLDivElement>, 'title' | 'children'> & {
    title: string;
    description: string;
    icon?: IconName;
    action?: ReactNode;
    tone?: 'neutral' | 'error';
    headingLevel?: 2 | 3 | 4;
};
export declare function EmptyState({ title, description, icon, action, tone, headingLevel, className, ...props }: EmptyStateProps): import("react").JSX.Element;
