import type { ReactNode } from 'react';
import type { SelectOption } from '../Select/Select';
export type WorkspaceSwitcherProps = {
    workspaces: SelectOption[];
    value: string | null;
    onChange: (id: string) => void;
    label?: string;
    variant?: 'field' | 'list';
    disabled?: boolean;
    actions?: ReactNode;
    className?: string;
};
export declare function WorkspaceSwitcher({ workspaces, value, onChange, label, variant, disabled, actions, className }: WorkspaceSwitcherProps): import("react").JSX.Element;
