import type { HTMLAttributes, ReactNode, Ref } from 'react';
export type PageHeaderProps = Omit<HTMLAttributes<HTMLElement>, 'title' | 'children'> & {
    title: string;
    description?: ReactNode;
    eyebrow?: string;
    breadcrumbs?: ReactNode;
    actions?: ReactNode;
    headingLevel?: 1 | 2 | 3 | 4;
    titleId?: string;
    titleRef?: Ref<HTMLHeadingElement>;
};
export declare function PageHeader({ title, description, eyebrow, breadcrumbs, actions, headingLevel, titleId, titleRef, className, ...props }: PageHeaderProps): import("react").JSX.Element;
