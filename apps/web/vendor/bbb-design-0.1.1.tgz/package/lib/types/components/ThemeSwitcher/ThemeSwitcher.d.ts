import type { ThemeMode } from '../ThemeProvider/ThemeProvider';
export type ThemeSwitcherProps = {
    value: ThemeMode;
    onChange: (mode: ThemeMode) => void;
    disabled?: boolean;
    label?: string;
    className?: string;
};
export declare function ThemeSwitcher({ value, onChange, disabled, label, className }: ThemeSwitcherProps): import("react").JSX.Element;
