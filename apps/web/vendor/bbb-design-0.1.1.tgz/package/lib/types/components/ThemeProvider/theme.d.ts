import type { CSSProperties } from 'react';
import type { BrandPreset, ThemeTokens } from '../../foundations/brands';
export type { Brand, ThemeTokens } from '../../foundations/brands';
export type ThemeMode = 'light' | 'dark' | 'system';
export type Density = 'comfortable' | 'compact';
export type Theme = {
    brand: string;
    preset: BrandPreset;
    mode: 'light' | 'dark';
    density: Density;
    tokens: ThemeTokens;
    overrides: ThemeTokens;
    dir?: 'ltr' | 'rtl';
    locale?: string;
};
export declare const ThemeContext: import("react").Context<Theme>;
export declare function themeAttributes(theme: Theme): {
    'data-bbb-theme': string;
    'data-bbb-brand': string;
    'data-bbb-mode': "light" | "dark";
    'data-bbb-density': Density;
    dir: "ltr" | "rtl" | undefined;
    lang: string | undefined;
    style: CSSProperties;
};
/** For BBB portals; attach attributes and the bbb-theme class to the portaled root. */
export declare function useThemeAttributes(): {
    'data-bbb-theme': string;
    'data-bbb-brand': string;
    'data-bbb-mode': "light" | "dark";
    'data-bbb-density': Density;
    dir: "ltr" | "rtl" | undefined;
    lang: string | undefined;
    style: CSSProperties;
};
