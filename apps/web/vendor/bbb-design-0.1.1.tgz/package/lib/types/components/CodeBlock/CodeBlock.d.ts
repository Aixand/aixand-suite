export type CodeBlockProps = {
    code: string;
    language?: string;
    label?: string;
    className?: string;
};
export declare function CodeBlock({ code, language, label, className }: CodeBlockProps): import("react").JSX.Element;
