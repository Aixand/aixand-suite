import type { ReactNode, RefObject } from 'react';
export type DocumentWorkspaceNavigationProps = {
    compact: boolean;
    /** Call after selecting a document to dismiss mobile navigation and focus the content. */
    onNavigate: () => void;
    /** Reveal the desktop library after choosing an icon-rail destination. */
    expandNavigation: () => void;
};
export type DocumentWorkspaceProps = {
    label: string;
    contentLabel: string;
    navigationLabel: string;
    openNavigationLabel: string;
    navigation: (props: DocumentWorkspaceNavigationProps) => ReactNode;
    account: ReactNode;
    tools?: ReactNode;
    children: ReactNode;
    footer?: ReactNode;
    navigationDisabled?: boolean;
    contentRef?: RefObject<HTMLDivElement | null>;
    className?: string;
};
/** A library and document surface, with account access in the document toolbar. */
export declare function DocumentWorkspace({ label, contentLabel, navigationLabel, openNavigationLabel, navigation, account, tools, children, footer, navigationDisabled, contentRef, className }: DocumentWorkspaceProps): import("react").JSX.Element;
