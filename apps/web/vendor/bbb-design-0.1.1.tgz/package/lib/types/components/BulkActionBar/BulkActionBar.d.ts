import type { ReactNode } from 'react';
export type BulkActionBarProps = {
    count: number;
    scope: string;
    onClear: () => void;
    children: ReactNode;
    className?: string;
};
/** Keep mounted while selection changes; the consumer restores row focus after bulk removal. */
export declare function BulkActionBar({ count, scope, onClear, children, className }: BulkActionBarProps): import("react").JSX.Element;
