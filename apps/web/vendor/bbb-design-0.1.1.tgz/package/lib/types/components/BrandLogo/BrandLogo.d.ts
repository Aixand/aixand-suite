import type { HTMLAttributes } from 'react';
import type { BrandPreset } from '../../foundations/brands';
export type BrandLogoProps = Omit<HTMLAttributes<HTMLSpanElement>, 'children'> & {
    brand?: BrandPreset;
    decorative?: boolean;
};
/** Uses the current brand's wordmark or mode-specific image. Wrap in a named link when interactive. */
export declare function BrandLogo({ brand, decorative, className, ...props }: BrandLogoProps): import("react").JSX.Element;
