import type { HTMLAttributes, ReactNode } from 'react';
export type DescriptionItem = {
    id: string;
    label: ReactNode;
    value: ReactNode;
};
export type DescriptionListProps = HTMLAttributes<HTMLDListElement> & {
    items: DescriptionItem[];
    layout?: 'rows' | 'stacked';
};
export declare function DescriptionList({ items, layout, className, ...props }: DescriptionListProps): import("react").JSX.Element;
