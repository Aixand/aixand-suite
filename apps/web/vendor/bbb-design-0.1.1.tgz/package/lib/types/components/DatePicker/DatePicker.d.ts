import type { DatePickerProps as AriaDatePickerProps, DateRangePickerProps as AriaDateRangePickerProps, TimeFieldProps, DateValue, TimeValue } from 'react-aria-components';
import type { FieldVariant } from '../FormField/FieldSurface';
type FieldOptions = {
    label: string;
    hint?: string;
    error?: string;
    variant?: FieldVariant;
    disabled?: boolean;
    required?: boolean;
    className?: string;
};
export declare function SegmentedDateInput({ slot }: {
    slot?: string;
}): import("react").JSX.Element;
export type DatePickerProps<T extends DateValue> = Omit<AriaDatePickerProps<T>, 'children' | 'className' | 'isDisabled' | 'isRequired'> & FieldOptions;
export declare function DatePicker<T extends DateValue>({ label, hint, error, variant, disabled, required, className, ...props }: DatePickerProps<T>): import("react").JSX.Element;
export type DateRangePickerProps<T extends DateValue> = Omit<AriaDateRangePickerProps<T>, 'children' | 'className' | 'isDisabled' | 'isRequired'> & FieldOptions;
export declare function DateRangePicker<T extends DateValue>({ label, hint, error, variant, disabled, required, className, ...props }: DateRangePickerProps<T>): import("react").JSX.Element;
export type TimePickerProps<T extends TimeValue> = Omit<TimeFieldProps<T>, 'children' | 'className' | 'isDisabled' | 'isRequired'> & FieldOptions;
export declare function TimePicker<T extends TimeValue>({ label, hint, error, variant, disabled, required, className, ...props }: TimePickerProps<T>): import("react").JSX.Element;
export {};
