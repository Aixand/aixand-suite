import type { DialogProps } from '../Dialog/Dialog';
export type SheetProps = Omit<DialogProps, 'role'> & {
    side?: 'start' | 'end';
};
export declare function Sheet({ side, ...props }: SheetProps): import("react").JSX.Element;
