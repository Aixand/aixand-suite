export type TreeViewItem = {
    id: string;
    label: string;
    disabled?: boolean;
    children?: TreeViewItem[];
};
export type TreeViewProps = {
    label: string;
    items: TreeViewItem[];
    selectedId?: string;
    onSelectionChange: (id: string) => void;
    expandedIds?: string[];
    defaultExpandedIds?: string[];
    onExpandedChange?: (ids: string[]) => void;
    className?: string;
};
export declare function TreeView({ label, items, selectedId, onSelectionChange, expandedIds, defaultExpandedIds, onExpandedChange, className }: TreeViewProps): import("react").JSX.Element;
