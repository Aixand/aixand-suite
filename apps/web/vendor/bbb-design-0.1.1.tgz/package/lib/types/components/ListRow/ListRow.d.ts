import type { ReactNode } from 'react';
export type ListRowProps = {
    label: string;
    description?: string;
    leading?: ReactNode;
    className?: string;
} & ({
    onAction: () => void;
    disabled?: boolean;
    href?: never;
    trailing?: never;
} | {
    href: string;
    onAction?: never;
    disabled?: never;
    trailing?: never;
} | {
    trailing?: ReactNode;
    onAction?: never;
    href?: never;
    disabled?: never;
});
export declare function ListRow({ label, description, leading, trailing, onAction, href, disabled, className, }: ListRowProps): import("react").JSX.Element;
