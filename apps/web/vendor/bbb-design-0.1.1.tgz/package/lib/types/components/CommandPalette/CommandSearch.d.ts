import type { ReactNode } from 'react';
import type { FieldVariant } from '../FormField/FieldSurface';
export type CommandItem = {
    id: string;
    label: string;
    group: string;
    description?: string;
    keywords?: string[];
    shortcut?: string[];
    href?: string;
    target?: string;
    leading?: ReactNode;
    disabled?: boolean;
};
export type CommandSearchProps = {
    label: string;
    items: CommandItem[];
    onAction: (id: string) => void;
    query?: string;
    onQueryChange?: (query: string) => void;
    loading?: boolean;
    autoFocus?: boolean;
    placeholder?: string;
    variant?: Exclude<FieldVariant, 'filled'>;
    className?: string;
};
export declare function CommandSearch({ label, items, onAction, query, onQueryChange, loading, autoFocus, placeholder, variant, className }: CommandSearchProps): import("react").JSX.Element;
