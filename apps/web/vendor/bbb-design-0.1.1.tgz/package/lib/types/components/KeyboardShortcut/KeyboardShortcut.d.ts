export type KeyboardShortcutProps = {
    keys: string[];
    label?: string;
    className?: string;
};
/** Visual hint only. The consuming application installs the shortcut. */
export declare function KeyboardShortcut({ keys, label, className }: KeyboardShortcutProps): import("react").JSX.Element;
