export declare function ColumnResizer({ label, width, onResize }: {
    label: string;
    width?: number;
    onResize: (width: number) => void;
}): import("react").JSX.Element;
