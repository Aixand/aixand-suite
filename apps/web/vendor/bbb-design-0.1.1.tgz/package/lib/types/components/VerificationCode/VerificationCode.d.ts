import type { TextFieldProps } from '../TextField/TextField';
export type VerificationCodeProps = Omit<TextFieldProps, 'value' | 'defaultValue' | 'onChange' | 'type' | 'maxLength' | 'minLength' | 'pattern'> & {
    value?: string;
    defaultValue?: string;
    onChange?: (value: string) => void;
    length?: number;
};
/** One native input preserves paste, autofill, selection, and screen-reader navigation. */
export declare function VerificationCode({ value, defaultValue, onChange, length, ref, className, ...props }: VerificationCodeProps): import("react").JSX.Element;
