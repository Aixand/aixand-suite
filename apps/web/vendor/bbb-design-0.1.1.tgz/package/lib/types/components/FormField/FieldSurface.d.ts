import type { ReactNode, Ref } from 'react';
export type FieldVariant = 'filled' | 'outlined' | 'subtle' | 'plain';
export type FieldSurfaceProps = {
    children: ReactNode;
    label?: ReactNode;
    variant?: FieldVariant;
    invalid?: boolean;
    ref?: Ref<HTMLDivElement>;
};
/** Places persistent labels inside filled fields and above simpler controls. */
export declare function FieldSurface({ children, label, variant, invalid, ref }: FieldSurfaceProps): import("react").JSX.Element;
