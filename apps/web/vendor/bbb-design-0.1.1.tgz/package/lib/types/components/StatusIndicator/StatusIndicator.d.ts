import type { IconName } from '../Icon/Icon';
export type StatusIndicatorProps = {
    label: string;
    tone?: 'neutral' | 'success' | 'warning' | 'danger';
    icon?: IconName;
    live?: boolean;
    className?: string;
};
export declare function StatusIndicator({ label, tone, icon, live, className }: StatusIndicatorProps): import("react").JSX.Element;
