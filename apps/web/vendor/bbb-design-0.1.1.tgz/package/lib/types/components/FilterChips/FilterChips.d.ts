import type { RefObject } from 'react';
type FilterChip = {
    id: string;
    label: string;
    disabled?: boolean;
};
export type FilterChipsProps = {
    className?: string;
    label: string;
    items: FilterChip[];
    onRemove: (id: string) => void;
    onClear?: (removableIds: string[]) => void;
    emptyFocusRef: RefObject<HTMLElement | null>;
    disabled?: boolean;
};
export declare function FilterChips({ label, items, onRemove, onClear, emptyFocusRef, disabled, className, }: FilterChipsProps): import("react").JSX.Element | null;
export {};
