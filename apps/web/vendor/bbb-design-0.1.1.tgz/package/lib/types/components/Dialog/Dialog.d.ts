import type { ReactElement, ReactNode } from 'react';
export type DialogProps = {
    className?: string;
    bodyClassName?: string;
    closeLabel?: string;
    trigger: ReactElement;
    title: string;
    description?: string;
    children?: ReactNode | ((close: () => void) => ReactNode);
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    role?: 'dialog' | 'alertdialog';
    footer?: ReactNode | ((close: () => void) => ReactNode);
};
export declare function Dialog(props: DialogProps): import("react").JSX.Element;
export declare function ModalDialog({ trigger, title, description, children, open, onOpenChange, role, placement, footer, className, bodyClassName, closeLabel, }: DialogProps & {
    placement?: 'center' | 'start' | 'end';
}): import("react").JSX.Element;
export type ConfirmationDialogProps = Omit<DialogProps, 'children' | 'role'> & {
    confirmLabel: string;
    cancelLabel?: string;
    onConfirm: () => void;
    danger?: boolean;
};
export declare function ConfirmationDialog({ confirmLabel, cancelLabel, onConfirm, danger, ...props }: ConfirmationDialogProps): import("react").JSX.Element;
