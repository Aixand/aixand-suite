import type { Ref } from 'react';
export declare function SidebarToggle({ collapsed, controls, onToggle, buttonRef, }: {
    collapsed: boolean;
    controls: string;
    onToggle: () => void;
    buttonRef: Ref<HTMLButtonElement>;
}): import("react").JSX.Element;
