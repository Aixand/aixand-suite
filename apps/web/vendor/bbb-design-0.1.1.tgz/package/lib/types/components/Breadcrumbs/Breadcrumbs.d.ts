type BreadcrumbItem = {
    id: string;
    label: string;
    href?: string;
};
export type BreadcrumbsProps = {
    items: BreadcrumbItem[];
    label?: string;
    className?: string;
};
export declare function Breadcrumbs({ items, label, className }: BreadcrumbsProps): import("react").JSX.Element | null;
export {};
