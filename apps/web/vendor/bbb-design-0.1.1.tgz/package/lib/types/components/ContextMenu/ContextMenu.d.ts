import type { ReactNode } from 'react';
import type { MenuAction } from '../DropdownMenu/DropdownMenu';
export type ContextMenuProps = {
    label: string;
    items: MenuAction[];
    onAction: (id: string) => void;
    children: ReactNode;
    className?: string;
};
/** Right-click and Shift+F10 open the same menu as the visible action button. */
export declare function ContextMenu({ label, items, onAction, children, className }: ContextMenuProps): import("react").JSX.Element;
