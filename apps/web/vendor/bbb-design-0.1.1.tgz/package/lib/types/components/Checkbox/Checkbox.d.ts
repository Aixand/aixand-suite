import type { CheckboxProps as AriaCheckboxProps } from 'react-aria-components';
export type CheckboxProps = Omit<AriaCheckboxProps, 'children' | 'className' | 'isDisabled'> & {
    label: string;
    hideLabel?: boolean;
    description?: string;
    disabled?: boolean;
    className?: string;
};
export declare function Checkbox({ label, hideLabel, description, disabled, className, ...props }: CheckboxProps): import("react").JSX.Element;
