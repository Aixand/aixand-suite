import type { ComponentPropsWithRef } from 'react';
export type LinkProps = ComponentPropsWithRef<'a'> & {
    external?: boolean;
    variant?: 'default' | 'quiet';
};
export declare function Link({ external, variant, target, rel, children, className, ...props }: LinkProps): import("react").JSX.Element;
