import type { ReactNode } from 'react';
export type SegmentedControlProps = {
    label: string;
    value?: string;
    defaultValue?: string;
    onChange?: (value: string) => void;
    disabled?: boolean;
    className?: string;
    options: {
        value: string;
        label: string;
        icon?: ReactNode;
        disabled?: boolean;
    }[];
};
export declare function SegmentedControl({ label, value, defaultValue, onChange, disabled, className, options, }: SegmentedControlProps): import("react").JSX.Element;
