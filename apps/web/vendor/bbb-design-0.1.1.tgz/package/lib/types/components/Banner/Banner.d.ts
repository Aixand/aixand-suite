import type { ReactNode } from 'react';
import type { AlertProps } from '../Alert/Alert';
export type BannerProps = AlertProps & {
    actions?: ReactNode;
    onDismiss?: () => void;
    dismissLabel?: string;
};
export declare function Banner({ children, actions, onDismiss, dismissLabel, className, ...props }: BannerProps): import("react").JSX.Element;
