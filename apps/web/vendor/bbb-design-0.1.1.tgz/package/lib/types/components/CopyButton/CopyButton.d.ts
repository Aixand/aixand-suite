import type { ButtonProps } from '../Button/Button';
export type CopyButtonProps = Omit<ButtonProps, 'onPress' | 'children' | 'loading'> & {
    text: string;
    label?: string;
    onCopy?: () => void;
    onCopyError?: (error: unknown) => void;
};
export declare function CopyButton(props: CopyButtonProps): import("react").JSX.Element;
