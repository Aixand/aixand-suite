import type { ReactElement, ReactNode } from 'react';
export type PopoverProps = {
    className?: string;
    trigger: ReactElement;
    title: string;
    children: ReactNode;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
};
export declare function Popover({ trigger, title, children, open, onOpenChange, className }: PopoverProps): import("react").JSX.Element;
