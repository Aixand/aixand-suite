/** Shared descriptions and native validation messages for composite fields. */
export declare function FieldFeedback({ hint, error }: {
    hint?: string;
    error?: string;
}): import("react").JSX.Element;
