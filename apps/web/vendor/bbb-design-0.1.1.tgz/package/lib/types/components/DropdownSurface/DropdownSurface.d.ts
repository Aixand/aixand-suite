import type { PopoverProps } from 'react-aria-components';
export type DropdownSurfaceProps = Omit<PopoverProps, 'className'> & {
    className?: string;
};
/** Shared floating treatment for action menus and field option lists. */
export declare function DropdownSurface({ className, ...props }: DropdownSurfaceProps): import("react").JSX.Element;
