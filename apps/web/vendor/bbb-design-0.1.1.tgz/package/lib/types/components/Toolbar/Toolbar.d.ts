import type { ToolbarProps as AriaToolbarProps } from 'react-aria-components';
import type { MenuAction } from '../DropdownMenu/DropdownMenu';
export type ToolbarProps = Omit<AriaToolbarProps, 'className'> & {
    label: string;
    className?: string;
    overflowActions?: MenuAction[];
    onOverflowAction?: (id: string) => void;
};
export declare function Toolbar({ label, className, children, overflowActions, onOverflowAction, ...props }: ToolbarProps): import("react").JSX.Element;
