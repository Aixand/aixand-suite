export declare function useSystemMode(): "light" | "dark";
