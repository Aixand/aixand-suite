export type StepperProps = {
    label: string;
    steps: string[];
    currentStep: number;
    className?: string;
};
/** Progress is informational; the surrounding form owns Back/Continue and validation. */
export declare function Stepper({ label, steps, currentStep, className }: StepperProps): import("react").JSX.Element;
