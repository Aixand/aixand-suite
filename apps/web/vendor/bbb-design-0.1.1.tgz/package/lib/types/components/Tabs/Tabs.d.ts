import type { TabsProps as AriaTabsProps } from 'react-aria-components';
import type { ReactNode } from 'react';
export type TabsProps = Omit<AriaTabsProps, 'children' | 'className'> & {
    label: string;
    items: {
        id: string;
        label: string;
        content: ReactNode;
        disabled?: boolean;
    }[];
    className?: string;
};
export declare function Tabs({ label, items, className, ...props }: TabsProps): import("react").JSX.Element;
