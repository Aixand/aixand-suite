import type { HTMLAttributes, ReactNode } from 'react';
export type CardProps = Omit<HTMLAttributes<HTMLDivElement>, 'title'> & {
    as?: 'div' | 'section';
    title?: string;
    description?: string;
    action?: ReactNode;
    footer?: ReactNode;
    headingLevel?: 2 | 3 | 4;
    variant?: 'default' | 'quiet';
};
export declare function Card({ as: Root, title, description, action, footer, headingLevel, variant, className, children, ...props }: CardProps): import("react").JSX.Element;
