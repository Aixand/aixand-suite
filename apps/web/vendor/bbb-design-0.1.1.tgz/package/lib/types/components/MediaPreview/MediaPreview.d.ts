export type MediaPreviewProps = {
    src: string;
    alt: string;
    caption?: string;
    className?: string;
};
export declare function MediaPreview({ src, alt, caption, className }: MediaPreviewProps): import("react").JSX.Element;
