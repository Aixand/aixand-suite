import type { AvatarProps } from '../Avatar/Avatar';
export type AvatarMember = Pick<AvatarProps, 'name' | 'src' | 'tone'> & {
    id: string;
};
export type AvatarGroupProps = {
    className?: string;
    label: string;
    members: AvatarMember[];
    maxVisible?: number;
    size?: AvatarProps['size'];
};
export declare function AvatarGroup({ label, members, maxVisible, size, className }: AvatarGroupProps): import("react").JSX.Element;
