export type FilterGroupProps<Value extends string> = {
    className?: string;
    label: string;
    value: Value;
    options: {
        value: Value;
        label: string;
        count: number;
    }[];
    onChange: (value: Value) => void;
};
export declare function FilterGroup<Value extends string>({ label, value, options, onChange, className, }: FilterGroupProps<Value>): import("react").JSX.Element;
