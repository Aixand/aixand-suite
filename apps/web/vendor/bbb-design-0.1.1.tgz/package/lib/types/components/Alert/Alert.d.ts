import type { HTMLAttributes, ReactNode } from 'react';
export type AlertTone = 'info' | 'success' | 'warning' | 'danger';
export type AlertProps = Omit<HTMLAttributes<HTMLDivElement>, 'title'> & {
    title: string;
    tone?: AlertTone;
    children?: ReactNode;
};
export declare function Alert({ title, tone, children, className, role, ...props }: AlertProps): import("react").JSX.Element;
