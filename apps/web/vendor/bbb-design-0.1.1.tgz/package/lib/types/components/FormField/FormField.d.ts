import type { ReactNode } from 'react';
import type { FieldVariant } from './FieldSurface';
export type FieldProps = {
    label: string;
    hideLabel?: boolean;
    hint?: string;
    error?: string;
    variant?: FieldVariant;
};
export type FormFieldProps = FieldProps & {
    id?: string;
    className?: string;
    describedBy?: string;
    children: (ids: {
        id: string;
        describedBy?: string;
    }) => ReactNode;
};
export declare function FormField({ label, hideLabel, hint, error, variant, id, className, describedBy, children, }: FormFieldProps): import("react").JSX.Element;
