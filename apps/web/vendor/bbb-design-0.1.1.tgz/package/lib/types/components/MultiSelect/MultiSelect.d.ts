import type { SelectProps as AriaSelectProps } from 'react-aria-components';
import type { ReactNode } from 'react';
import type { ChoiceOption } from '../DropdownSurface/OptionContent';
import type { FieldVariant } from '../FormField/FieldSurface';
export type MultiSelectProps = Omit<AriaSelectProps<ChoiceOption, 'multiple'>, 'children' | 'className' | 'value' | 'defaultValue' | 'onChange' | 'selectionMode' | 'isDisabled' | 'isRequired' | 'disabledKeys'> & {
    label: string;
    options: ChoiceOption[];
    value?: string[];
    defaultValue?: string[];
    onChange?: (value: string[]) => void;
    hint?: string;
    error?: string;
    variant?: FieldVariant;
    disabled?: boolean;
    required?: boolean;
    className?: string;
    renderOption?: (option: ChoiceOption) => ReactNode;
};
export declare function MultiSelect({ label, options, value, defaultValue, onChange, hint, error, variant, disabled, required, className, renderOption, ...props }: MultiSelectProps): import("react").JSX.Element;
