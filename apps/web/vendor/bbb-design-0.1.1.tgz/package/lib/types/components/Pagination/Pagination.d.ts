export type PaginationProps = {
    className?: string;
    page: number;
    pageSize: number;
    totalItems: number;
    onPageChange: (page: number) => void;
    label?: string;
    disabled?: boolean;
};
export declare function Pagination({ page, pageSize, totalItems, onPageChange, label, disabled, className, }: PaginationProps): import("react").JSX.Element;
