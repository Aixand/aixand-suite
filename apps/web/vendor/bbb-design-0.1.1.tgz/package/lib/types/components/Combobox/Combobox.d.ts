import type { ChoiceOption } from '../DropdownSurface/OptionContent';
import type { ReactNode } from 'react';
import type { ComboBoxProps as AriaComboBoxProps } from 'react-aria-components';
import type { FieldVariant } from '../FormField/FieldSurface';
export type ComboboxOption = ChoiceOption;
export type ComboboxProps = Omit<AriaComboBoxProps<ComboboxOption>, 'children' | 'className' | 'items' | 'defaultItems' | 'isDisabled' | 'disabledKeys'> & {
    label: string;
    options: ComboboxOption[];
    placeholder?: string;
    hint?: string;
    error?: string;
    variant?: FieldVariant;
    disabled?: boolean;
    loading?: boolean;
    emptyMessage?: string;
    renderOption?: (option: ComboboxOption) => ReactNode;
    className?: string;
};
export declare function Combobox({ label, options, placeholder, hint, error, variant, disabled, loading, emptyMessage, renderOption, className, ...props }: ComboboxProps): import("react").JSX.Element;
