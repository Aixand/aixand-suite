import type { DisclosureGroupProps } from 'react-aria-components';
import type { ReactNode } from 'react';
export type AccordionProps = Omit<DisclosureGroupProps, 'children' | 'className'> & {
    items: {
        id: string;
        title: string;
        content: ReactNode;
        disabled?: boolean;
    }[];
    className?: string;
};
export declare function Accordion({ items, className, ...props }: AccordionProps): import("react").JSX.Element;
