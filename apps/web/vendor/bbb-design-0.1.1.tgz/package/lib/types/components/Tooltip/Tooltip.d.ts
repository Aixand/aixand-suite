import type { ReactElement } from 'react';
import type { TooltipProps as AriaTooltipProps } from 'react-aria-components';
export type TooltipProps = {
    children: ReactElement;
    content: string;
    className?: string;
    placement?: AriaTooltipProps['placement'];
    disabled?: boolean;
};
export declare function Tooltip({ children, content, placement, disabled, className }: TooltipProps): import("react").JSX.Element;
