import type { ReactNode } from 'react';
export type TableSort = {
    column: string;
    direction: 'ascending' | 'descending';
};
export type TableColumn<Row> = {
    id: string;
    label: string;
    renderCell: (row: Row) => ReactNode;
    rowHeader?: boolean;
    sortable?: boolean;
    align?: 'start' | 'end';
};
export type TableProps<Row> = {
    label: string;
    rows: Row[];
    columns: TableColumn<Row>[];
    getRowId: (row: Row) => string;
    getRowLabel: (row: Row) => string;
    sort?: TableSort;
    onSortChange?: (sort: TableSort) => void;
    selection?: {
        selectedIds: ReadonlySet<string>;
        onChange: (ids: Set<string>) => void;
        isDisabled?: (row: Row) => boolean;
    };
    loading?: boolean;
    emptyState?: ReactNode;
    hiddenColumnIds?: ReadonlySet<string>;
    columnWidths?: Readonly<Record<string, number>>;
    onColumnResize?: (id: string, width: number) => void;
    expandedRowIds?: ReadonlySet<string>;
    onExpandedRowsChange?: (ids: Set<string>) => void;
    renderExpandedRow?: (row: Row) => ReactNode;
};
export declare function Table<Row>({ label, rows, columns, getRowId, getRowLabel, sort, onSortChange, selection, loading, emptyState, hiddenColumnIds, columnWidths, onColumnResize, expandedRowIds, onExpandedRowsChange, renderExpandedRow, }: TableProps<Row>): import("react").JSX.Element;
