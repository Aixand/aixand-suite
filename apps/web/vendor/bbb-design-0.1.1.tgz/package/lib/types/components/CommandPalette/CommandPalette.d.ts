import type { ReactElement } from 'react';
import type { CommandSearchProps } from './CommandSearch';
export type { CommandItem, CommandSearchProps } from './CommandSearch';
export type CommandPaletteProps = Omit<CommandSearchProps, 'autoFocus' | 'label'> & {
    trigger: ReactElement;
    title: string;
    searchLabel?: string;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** Opt in on one app-level palette. Ignored while typing or another dialog is open. */
    shortcut?: string;
};
export declare function CommandPalette({ trigger, title, searchLabel, open, onOpenChange, shortcut, onAction, ...props }: CommandPaletteProps): import("react").JSX.Element;
