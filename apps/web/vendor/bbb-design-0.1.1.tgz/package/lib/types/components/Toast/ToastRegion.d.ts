import type { createToastQueue } from './toastQueue';
export declare function ToastRegion({ queue }: {
    queue: ReturnType<typeof createToastQueue>;
}): import("react").JSX.Element | null;
