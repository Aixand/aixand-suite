export type LoadingIndicatorProps = {
    label?: string;
    hideLabel?: boolean;
    className?: string;
};
export declare function LoadingIndicator({ label, hideLabel, className }: LoadingIndicatorProps): import("react").JSX.Element;
