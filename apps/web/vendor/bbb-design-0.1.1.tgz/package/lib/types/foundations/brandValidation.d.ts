import type { BrandPreset, ThemeTokens } from './brands';
export type BrandIssue = {
    path: string;
    message: string;
};
/** Resolves aliases for validation only. Exported presets keep their references. */
export declare function resolveBrandValue(value: string, tokens: ThemeTokens, visited?: Set<string>): string;
/** Shape/reference checks work on the server; CSS value checks also run in a browser. */
export declare function validateBrand(input: unknown): BrandIssue[];
export declare function parseBrand(json: string): BrandPreset;
export declare function serializeBrand(brand: BrandPreset): string;
/** Mode-specific, scoped CSS. Import after BBB styles; aliases stay intact. */
export declare function brandToCSS(brand: BrandPreset): string;
