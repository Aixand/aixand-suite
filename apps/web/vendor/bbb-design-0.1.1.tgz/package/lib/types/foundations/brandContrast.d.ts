import type { BrandPreset, BrandMode } from './brands';
export type BrandContrastCheck = {
    mode: BrandMode;
    label: string;
    ratio: number | null;
    minimum: number;
    pass: boolean;
};
/** Browser-only color evaluation supports CSS colors and aliases, including alpha. */
export declare function checkBrandContrast(brand: BrandPreset): BrandContrastCheck[];
