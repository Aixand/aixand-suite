export type ThemeTokens = Partial<Record<`--bbb-${string}`, string>>;
export type BrandMode = 'light' | 'dark';
export type BrandLogoDefinition = {
    type: 'wordmark';
    text: string;
    suffix?: string;
    label: string;
} | {
    type: 'image';
    light: string;
    dark?: string;
    label: string;
};
export type BrandPreset = {
    schemaVersion: 1;
    id: string;
    name: string;
    logo: BrandLogoDefinition;
    tokens: ThemeTokens;
    modes: Record<BrandMode, ThemeTokens>;
};
export declare const foundationTokens: Readonly<ThemeTokens>;
export declare const brandTokenNames: readonly `--bbb-${string}`[];
export declare const bbbBrand: BrandPreset;
export declare const studioBrand: BrandPreset;
export declare const brandPresets: {
    readonly bbb: BrandPreset;
    readonly studio: BrandPreset;
};
export type Brand = keyof typeof brandPresets;
/** Inheritance is flattened, so a saved preset has no dependency on a registry. */
export declare function createBrand(input: {
    id: string;
    name: string;
    extends?: BrandPreset;
    logo?: BrandLogoDefinition;
    tokens?: ThemeTokens;
    modes?: Partial<Record<BrandMode, ThemeTokens>>;
}): BrandPreset;
export declare function brandTokens(brand: BrandPreset, mode: BrandMode): ThemeTokens;
