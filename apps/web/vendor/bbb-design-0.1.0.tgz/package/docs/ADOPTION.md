# Use BBB in another React app

The repository provides the Gallery application and an ES module component library.
The package is private; no registry publishing is performed by these commands.
React 19.2+ is supplied by the consuming app. React Aria Components and
@internationalized/date are runtime dependencies.

```sh
npm ci
npm run lint
npm run build
npm test
npm run build:lib
npm pack --pack-destination /tmp
```

`npm pack` runs the library build through `prepack` and produces
`/tmp/bbb-design-0.1.0.tgz`. Install that local artifact in another application:

```sh
npm install /tmp/bbb-design-0.1.0.tgz
```

```tsx
import { ThemeProvider, Button, TextField, DatePicker, parseDate } from 'bbb-design'
import 'bbb-design/styles.css'

export function Example() {
  return (
    <ThemeProvider brand="bbb" mode="system" locale="en-US">
      <form onSubmit={event => event.preventDefault()}>
        <TextField label="Project name" name="project" required />
        <DatePicker label="Start date" defaultValue={parseDate('2026-10-01')} />
        <Button type="submit">Create project</Button>
      </form>
    </ThemeProvider>
  )
}
```

The public entry point is `src/index.ts`. Types ship with the library. Import CSS
once; JavaScript does not inject it. The stylesheet includes the baseline box
sizing, body margin reset, typography, focus and visually-hidden/icon utilities,
shared tokens, presets, and component styles. Assess the global baseline when
integrating into an existing app. `bbb-design/tokens.css` exports only the token
source for non-React consumers; it does not include component styling.

`npm run build` builds Gallery into `dist/`; `npm run build:lib` builds the public
library into `lib/`. Gallery demos, sample product data, and authentication/upload
simulations are not included in the library. The library keeps React and its
behavior dependencies external rather than bundling a second copy.

Pattern source under `src/pages/Gallery/patterns/` is a composition reference.
Adapt its product copy, data loading, routing, persistence and validation to your
application. Authentication is a local demonstration, file progress is simulated,
and no example connects to a server. Do not use those simulations as backend code.

Read [customization](./CUSTOMIZATION.md) for themes, icons, and content slots,
[foundations](./FOUNDATIONS.md) for interaction contracts, and the
[component API guide](../src/components/README.md) for individual controls.

## Releases and compatibility

0.1.0 establishes the first consumable library entry. Keep changes recorded in
CHANGELOG.md and update the version before distributing a new artifact. Patch
releases fix behavior without changing APIs; minor releases add compatible APIs.
Before 1.0, breaking API changes require a minor version bump and migration notes;
after 1.0 they require a major version bump. Document deprecated props in the API
guide and retain an adapter through at least the next minor release when feasible.
Do not silently change controlled-value types or event shapes.

A release requires lint, TypeScript/Gallery and library builds, browser checks,
a package dry run, and a consumer import/type check. Run theme/keyboard/reflow
checks when changing tokens or controls. Registry publication and its access
settings remain a separate, explicitly configured release action.

### Product utilities

The library exports ThemeSwitcher, AppearanceSettings, AccountMenu,
WorkspaceSwitcher, CopyButton, CodeBlock, KeyboardShortcut, LoadingIndicator,
StatusIndicator, Banner, BulkActionBar, NotificationCenter, SplitPane, TreeView,
ContextMenu, and MediaPreview, plus their public prop/item types. Existing exports
remain available. Theme and account controls are controlled compositions: connect
them to application state and services, rather than importing Gallery simulations.
See the component guide for usage and interaction contracts.
